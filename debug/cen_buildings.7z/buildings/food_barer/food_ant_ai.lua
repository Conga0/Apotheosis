
local entity_id = GetUpdatedEntityID()
local pos_x, pos_y, rotation = EntityGetTransform(entity_id)
local controlscomp = EntityGetFirstComponentIncludingDisabled(entity_id,"ControlsComponent")
local sprite_comp = EntityGetFirstComponentIncludingDisabled(entity_id,"SpriteComponent")
local sprite_food_comp = EntityGetComponentIncludingDisabled(entity_id,"SpriteComponent")[2]
local vsc_animation_data = EntityGetComponentIncludingDisabled(entity_id,"VariableStorageComponent")[1]
local vsc_burrowing_data = EntityGetComponentIncludingDisabled(entity_id,"VariableStorageComponent")[2]
local vsc_navigation_data = EntityGetComponentIncludingDisabled(entity_id,"VariableStorageComponent")[3]
local vsc_feeding_data = EntityGetComponentIncludingDisabled(entity_id,"VariableStorageComponent")[4]

local target_entity = ComponentGetValue2(vsc_navigation_data,"value_int")
local c_x, c_y = EntityGetTransform(target_entity)
local direction_to_goal = pos_x < c_x and "mButtonDownRight" or "mButtonDownLeft"
local distance_from_goal = math.abs(c_y - pos_y) + math.abs(c_x - pos_x)

local animation_expiration_frame = ComponentGetValue2(vsc_animation_data,"value_int")
local current_animation = ComponentGetValue2(vsc_animation_data,"value_string")
local has_found_centipede = ComponentGetValue2(vsc_animation_data,"value_bool")

local is_burrowing = ComponentGetValue2(vsc_burrowing_data,"value_bool")
local burrow_speed = ComponentGetValue2(vsc_burrowing_data,"value_float")
local burrow_goal = ComponentGetValue2(vsc_burrowing_data,"value_int")

local last_loc_check_distance = ComponentGetValue2(vsc_navigation_data,"value_float")
local burrow_timeout_frame = tonumber(ComponentGetValue2(vsc_navigation_data,"value_string"))
local disable_ai = ComponentGetValue2(vsc_navigation_data,"value_bool")

local next_frame_can_collect_minimum = ComponentGetValue2(vsc_feeding_data,"value_int")



local distance_to_throw = EntityHasTag(target_entity,"centipede_head") and 96 or 16 --How close the ant needs to be to the target to throw meat towards the centipede, or to collect food from the food pile
local collect_minimum_cooldown = 600 --Minimum time in frames the ant should wait between collecting 2 pieces of meat
local idle_animation_name = "walk"


function getWithinRange(value,goal,range)
    if value < goal + range and value > goal - range then
        return true
    end
    return false
end

function setAnimationData(entity_id,animation_frames,animation_to_play)
    ComponentSetValue2(sprite_comp,"rect_animation",animation_to_play)
    ComponentSetValue2(sprite_food_comp,"rect_animation",animation_to_play)

	ComponentSetValue2(vsc_animation_data,"value_int",GameGetFrameNum() + animation_frames)
	ComponentSetValue2(vsc_animation_data,"value_string",animation_to_play)
end

function checkForAnimationTimeout(entity_id,animation_expiration_frame)
    if GameGetFrameNum() == animation_expiration_frame then
        ComponentSetValue2(sprite_comp,"rect_animation",idle_animation_name)
        ComponentSetValue2(sprite_food_comp,"rect_animation",idle_animation_name)
        ComponentSetValue2(vsc_animation_data,"value_string",idle_animation_name)
    end
end

function runActionCheck()
    if has_found_centipede then return end
    if distance_from_goal < distance_to_throw then
        local did_hit = Raytrace( pos_x, pos_y, c_x, c_y )
        local did_hit2 = Raytrace( pos_x, pos_y - 15, c_x, c_y )
        if did_hit == true or did_hit2 == true then return end

        ComponentSetValue2(controlscomp,"mButtonDownRight",false)
        ComponentSetValue2(controlscomp,"mButtonDownLeft",false)

        --If the ant is waiting for its minimum food collection cooldown, then do an early return here
        if EntityHasTag(target_entity,"centipede_food_pile") and next_frame_can_collect_minimum > GameGetFrameNum() then setAnimationData(entity_id,next_frame_can_collect_minimum - GameGetFrameNum(),"stand") return end

        setAnimationData(entity_id,29,"attack")
        ComponentSetValue2(vsc_animation_data,"value_float",GameGetFrameNum() + 15)
        ComponentSetValue2(vsc_animation_data,"value_bool",true)
    elseif is_burrowing == false then
        --Move ant towards centipede
        ComponentSetValue2(controlscomp,direction_to_goal,true)
    end
end

function scaleCheck()
    if pos_x < c_x then
        EntitySetTransform(entity_id, pos_x, pos_y, rotation, 1, 1)
    else
        EntitySetTransform(entity_id, pos_x, pos_y, rotation, -1, 1)
    end
end

function throwFoodCheck()
    if ComponentGetValue2(vsc_animation_data,"value_float") == GameGetFrameNum() then
        toggleMatterEater(false)
        local mucus_comp = EntityGetFirstComponentIncludingDisabled(entity_id,"ParticleEmitterComponent")
        EntitySetComponentIsEnabled( entity_id, mucus_comp, false )

        if EntityHasTag(target_entity,"centipede_food_pile") then
            --Pickup food from pile
            EntitySetComponentIsEnabled( entity_id, sprite_food_comp, true )
            EntityAddTag(entity_id,"centipede_food")
            ComponentSetValue2(vsc_feeding_data,"value_int",GameGetFrameNum() + collect_minimum_cooldown)
        else
            --Throw food to centipede
            local pid = EntityLoad("data/entities/animals/boss_adult_centipede/buildings/food_barer/food.xml", pos_x, pos_y)
            GameShootProjectile( entity_id, pos_x, pos_y, c_x, c_y, pid)
            EntitySetComponentIsEnabled( entity_id, sprite_food_comp, false )
            EntityRemoveTag(entity_id,"centipede_food")
        end
    elseif ComponentGetValue2(vsc_animation_data,"value_float") + 15 == GameGetFrameNum() then
        setAnimationData(entity_id,45,"stand")
    elseif ComponentGetValue2(vsc_animation_data,"value_float") + 60 == GameGetFrameNum() then
        if EntityHasTag(target_entity,"centipede_food_pile") then
            --Set target to centipede
            ComponentSetValue2(vsc_navigation_data,"value_int",EntityGetWithTag("centipede_head")[1])
            ComponentSetValue2(vsc_animation_data,"value_bool",false)
        else
            --Set target to food pile
            ComponentSetValue2(vsc_navigation_data,"value_int",EntityGetWithTag("centipede_food_pile")[1])
            ComponentSetValue2(vsc_animation_data,"value_bool",false)
        end
        --[[
        EntitySetComponentIsEnabled( entity_id, EntityGetFirstComponentIncludingDisabled(entity_id,"CharacterCollisionComponent"), false )
        ComponentSetValue2(vsc_burrowing_data,"value_bool",true)
        ComponentSetValue2(vsc_burrowing_data,"value_int",pos_y + 50)
        ComponentSetValue2(vsc_burrowing_data,"value_string","kill")
        ]]--
    end
end

function burrowAnimationData()
    if is_burrowing then
        if getWithinRange(pos_y,burrow_goal,10) == true or GameGetFrameNum() == burrow_timeout_frame then
            ComponentSetValue2(vsc_burrowing_data,"value_bool",false)
            if ComponentGetValue2(vsc_burrowing_data,"value_string") == "kill" then EntityKill(entity_id) end
        else
            if pos_y > burrow_goal then burrow_speed = burrow_speed * -1 end
            pos_y = pos_y + burrow_speed
        end
    end
end

function unstuckEntity()
    --Early return if the ant is being dismissed
    if ComponentGetValue2(vsc_burrowing_data,"value_string") == "kill" then return end
    ComponentSetValue2(vsc_navigation_data,"value_string",tostring(GameGetFrameNum() + 90))
    ComponentSetValue2(vsc_burrowing_data,"value_bool",true)
    ComponentSetValue2(vsc_burrowing_data,"value_float",0.5)
    ComponentSetValue2(vsc_burrowing_data,"value_int",c_y)
    toggleMatterEater(true)
    setAnimationData(entity_id,29,"attack")
end

function unstuckEntityUndo()
    toggleMatterEater(false)
end

function mucusCheck()
    if GameGetFrameNum() % 30 == 0 then
        local did_hit_left = Raytrace( pos_x - 8, pos_y, pos_x - 8, pos_y + 30 )
        local did_hit_right = Raytrace( pos_x + 8, pos_y, pos_x + 8, pos_y + 30 )
        if did_hit_left == false or did_hit_right == false then
            local mucus_comp = EntityGetFirstComponentIncludingDisabled(entity_id,"ParticleEmitterComponent")
            EntitySetComponentIsEnabled( entity_id, mucus_comp, true )
        end
    end
end

function toggleMatterEater(is_enabled)
    local children = EntityGetAllChildren(entity_id)
    for k=1,#children do
        local eater_comp = EntityGetFirstComponentIncludingDisabled(children[k],"CellEaterComponent") or 0
        if eater_comp ~= 0 then EntitySetComponentIsEnabled( entity_id, eater_comp, is_enabled ) end
    end
end

function navigationStuckCheck(distance_from_goal,last_loc_check_distance)
    if GameGetFrameNum() % 120 == 0 and current_animation ~= "stand" then
        if last_loc_check_distance == distance_from_goal then
            unstuckEntity()
        else
            ComponentSetValue2(vsc_navigation_data,"value_float",distance_from_goal)
            unstuckEntityUndo()
        end
    end
end

if disable_ai ~= true then
    runActionCheck()
    burrowAnimationData()
    scaleCheck()
    throwFoodCheck()
    checkForAnimationTimeout(entity_id,animation_expiration_frame)
    navigationStuckCheck(distance_from_goal,last_loc_check_distance)
    mucusCheck()
end



function death( damage_type_bit_field, damage_message, entity_thats_responsible, drop_items )
    local centipede_head = EntityGetWithTag("centipede_head")[1]
	local centipede_anger_comp = EntityGetComponentIncludingDisabled(centipede_head,"VariableStorageComponent")[1]
    ComponentSetValue2(centipede_anger_comp,"value_float",1.0)
end