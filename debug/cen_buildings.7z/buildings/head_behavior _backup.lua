
local entity_id = GetUpdatedEntityID()
local pos_x, pos_y, rotation, scale_x, scale_y = EntityGetTransform(entity_id)
local vsc_comps = EntityGetComponentIncludingDisabled(entity_id,"VariableStorageComponent")
local vsc_anger_data = vsc_comps[1]
local vsc_animation_data = vsc_comps[2]
local vsc_sound_data = vsc_comps[3]
local times_angered = ComponentGetValue2(vsc_anger_data,"value_int")

local current_target = 0
local default_rotation = 0

----Order of operations:
--1. Rotate towards current target (see rotation order)
--2. Run animations
--3. Check if the centipede should be roaring
--4. Emerge if it's time

----Head Behavior, in order of priority:
--Emerge from his hole to begin the fight
--Roar & shake head because his feeding ant was killed
--Eat food when it's nearby
--Look at incoming food
--Shake head at player if angered at least once previously
--Tilt head towards player if nearby
--If nothing else, look at food stockpile

----Rotation order of priority:
--If roaring, tilt the head all the way towards the player
--Do not tilt head further than (20) degrees of deviation away from food stockpile

function BeginFight()

end

local function rotateTo(current, goal, maxStep)
    local function normalizeAngle(angle)
        while angle > math.pi do
            angle = angle - 2 * math.pi
        end
        while angle < -math.pi do
            angle = angle + 2 * math.pi
        end
        return angle
    end

    local diff = normalizeAngle(goal - current)

    if math.abs(diff) <= maxStep then
        return goal
    else
        return current + math.sign(diff) * maxStep
    en

function math.sign(x)
    if x > 0 then
        return 1
    elseif x < 0 then
        return -1
    else
        return 0
    end
end
d
end

function lerp(a, b, weight)
	return a * weight + b * (1 - weight)
end

function RunAnimation(entity_id,wait_frames,animation_to_play)
	local sprite_comp = EntityGetFirstComponentIncludingDisabled(entity_id,"SpriteComponent")
    ComponentSetValue2(sprite_comp,"rect_animation",animation_to_play)
	ComponentSetValue2(vsc_animation_data,"value_int",GameGetFrameNum() + wait_frames)
	ComponentSetValue2(vsc_animation_data,"value_string",animation_to_play)
end

function find_target()

end

--Manually handle visual rotation
local rotation_goal = 0
local food = EntityGetInRadiusWithTag(pos_x,pos_y,256,"centipede_food") or {}
if #food > 0 then current_target = food[1] end

if EntityGetIsAlive(current_target) == false then current_target = 0 end

local ctarg_x,ctarg_y = 0,0
if current_target ~= 0 then
    ctarg_x,ctarg_y = EntityGetTransform(current_target)
end

if current_target ~= 0 or rotation ~= default_rotation then
    if type(bias_data) == "table" then ctarg_x = ctarg_x + bias_data[1] ctarg_y = ctarg_y + bias_data[2] end
    if current_target ~= 0 then rotation_goal = math.atan2( ( ctarg_y - pos_y ), ( ctarg_x - pos_x ) ) end
    if spin_speed ~= 0 then rotation_goal = rotation + spin_speed end
    local rotate_speed = (spin_speed ~= 0.0 and spin_speed) or 0.06
    local new_rotation = rotateTo(rotation, rotation_goal, rotate_speed)

    scale_x = 1
    if math.abs(new_rotation) > (math.pi / 2) then
        scale_y = -1
    else
        scale_y = 1
    end

    EntitySetTransform(entity_id,pos_x,pos_y,new_rotation,scale_x,scale_y)
end

--Check for animations
--Check if the centipede has been angered, if so begin the roar
if ComponentGetValue2(vsc_anger_data,"value_bool") == true and ComponentGetValue2(vsc_animation_data,"value_string") == "idle" then
    ComponentSetValue2(vsc_anger_data,"value_int",times_angered + 1)
    ComponentSetValue2(vsc_anger_data,"value_bool",false)

    RunAnimation(entity_id,90,"roar")
elseif #food > 0 and current_target == food[1] and ComponentGetValue2(vsc_animation_data,"value_string") == "idle" then
    local desired_food = food0
end

if ComponentGetValue2(vsc_animation_data,"value_int") == GameGetFrameNum() then
	local sprite_comp = EntityGetFirstComponentIncludingDisabled(entity_id,"SpriteComponent")
    ComponentSetValue2(sprite_comp,"rect_animation","idle")
	ComponentSetValue2(vsc_animation_data,"value_string","idle")
end

if ComponentGetValue2(vsc_animation_data,"value_string") == "roar" then
    --Enable roar animation
end

if times_angered >= 3 then

else

end

--Check for scream


--Check for emergence

