
local entity_id = GetUpdatedEntityID()
local pos_x, pos_y = EntityGetTransform(entity_id)
local vsc_comps = EntityGetComponentIncludingDisabled(entity_id,"VariableStorageComponent")
local vsc_anger_data = vsc_comps[1]
local vsc_anger_data_timer = vsc_comps[4]
local vsc_animation_data = vsc_comps[2]
local vsc_animation_shake_data = vsc_comps[5]
local vsc_unstuck_data = vsc_comps[3]
local vsc_rotation_data = vsc_comps[6]

local times_angered = tonumber(ComponentGetValue2(vsc_anger_data,"value_string"))
local anger_frames = ComponentGetValue2(vsc_anger_data,"value_int")
local current_irritation = ComponentGetValue2(vsc_anger_data,"value_float") --Set to 1 if an ant dies, incremented by 0.33 if his food is deflected
local is_currently_mad = ComponentGetValue2(vsc_anger_data,"value_bool")

local anger_expiration_frame = ComponentGetValue2(vsc_anger_data_timer,"value_int")

local last_frame_fed = ComponentGetValue2(vsc_unstuck_data,"value_int")

local current_animation_expiration_frame = ComponentGetValue2(vsc_animation_data,"value_int")
local current_animation = ComponentGetValue2(vsc_animation_data,"value_string")
local is_currently_emerging = ComponentGetValue2(vsc_animation_data,"value_bool")

local shake_start_frame = ComponentGetValue2(vsc_animation_shake_data,"value_int")
local rotation_offset = ComponentGetValue2(vsc_animation_shake_data,"value_float")
local shake_duration = tonumber(ComponentGetValue2(vsc_animation_shake_data,"value_string"))

local default_target = EntityGetWithTag("centipede_food_pile")[1]
local player = EntityGetWithTag("player_unit")[1]
local plyr_x, plyr_y = EntityGetTransform(player)
local distance_from_player = math.abs(plyr_y - pos_y) + math.abs(plyr_x - pos_x)
local food = EntityGetInRadiusWithTag(pos_x,pos_y,128,"centipede_food") or {}
local distance_from_food = 9999
if #food > 0 then
    local f_x, f_y = EntityGetTransform(food[1])
    distance_from_food = math.abs(f_y - pos_y) + math.abs(f_x - pos_x)
end

local rotation = ComponentGetValue2(vsc_rotation_data,"value_float")





local angry_at_player_duration = 300
local roar_animation_duration = 120             --How long you want the roar animation to be, this should ideally match the length of the roar sound effect
local roar_long_animation_duration = 240        --How long you want the emerging roar animation to be, this should ideally match the length of the emerging roar sound effect
local shake_head_animation_duration = 170       --How long you want the shaking to be in frames
local shake_animation_full_cycle_length = 80    --Full frame cycle to go between the following rot cycle: 0, -20, 0, 20, 0 |||| ie if this value was 80: (frame 0 rot 0 | frame 20 rot -20 | frame 40 rot 0 | frame 60 rot 20 | frame 80 rot 0)
local shake_animation_max_rot_deviation = 60    --Maximum rotation the head will shake out at, gradually decayed down to 0
local shake_animation_chance = 400              --Chance for the head to shake each frame, ie if this was 400, it would be in 1 in 400 chance to shake each frame
local notice_player_radius  = 128               --How close the player needs to be for the centipede to notice the player while the centipede is idle
local no_feed_anger_timer = 1800                --How many frames the centipede should go without being fed to become irritated
local rotation_speed = is_currently_mad and 0.06 or (times_angered > 0 or distance_from_food < notice_player_radius*2) and 0.02 or 0.01
local idle_animation_name = times_angered > 0 and "stand" or (distance_from_player < notice_player_radius or distance_from_food < notice_player_radius*2) and "peek" or "dormant"
local roar_animation_name = "open"
local shake_animation_name = "shake"
local eat_animation_name = "consume"



math.randomseed(GameGetFrameNum())

----Order of operations:
--1. Rotate towards current target (see rotation order)
--2. Check for if the centipede has been angered
--2.5. Run animations
--3. Check if the centipede should be roaring
--4. Emerge if it's time

----Head Behavior, in order of priority:
--Emerge from his hole to begin the fight
--Roar & shake head because his feeding ant was killed
--Eat food when it's nearby
--Look at incoming food
--Shake head at player if angered at least once previously
--Tilt head towards player if nearby
--If nothing else, look at food stockpile

----Rotation order of priority:
--If roaring, tilt the head all the way towards the player
--Do not tilt head further than (45) degrees of deviation away from food stockpile




------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------- Utility Functions ----------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function lerp(a, b, weight)
	return a * weight + b * (1 - weight)
end

local function rotateTo(current, goal, default_target, maxStep, rotation_offset, ignore_rotation_limit)
    local max_deviation = math.rad(45) -- Convert 45 degrees to radians
    local rot_offset = math.rad(rotation_offset)

    local function normalizeAngle(angle)
        while angle > math.pi do
            angle = angle - 2 * math.pi
        end
        while angle < -math.pi do
            angle = angle + 2 * math.pi
        end
        return angle
    end

    -- Get the angle to the default target
    local default_angle
    if default_target then
        local cx, cy = EntityGetTransform(entity_id)
        local dx, dy = EntityGetTransform(default_target)
        default_angle = math.atan2(dy - cy, dx - cx)
    else
        default_angle = current
    end

    -- Normalize angles
    local normalized_goal = normalizeAngle(goal)
    local normalized_current = normalizeAngle(current)
    local normalized_default = normalizeAngle(default_angle)

    -- Calculate the difference between goal and current
    local diff = normalizeAngle(goal - current)

    -- If ignore_rotation_limit is false, clamp the goal angle to within 45 degrees of default
    if not ignore_rotation_limit then
        local deviation = normalizeAngle(normalized_goal - normalized_default)
        if math.abs(deviation) > max_deviation then
            -- Clamp the goal angle to the max deviation
            normalized_goal = normalized_default + math.sign(deviation) * max_deviation
            diff = normalizeAngle(normalized_goal - normalized_current)
        end
    end

    -- Apply rotation step limit
    if math.abs(diff) <= maxStep then
        return normalized_goal
    else
        return normalized_current + math.sign(diff) * maxStep
    end
end

function math.sign(x)
    if x > 0 then
        return 1
    elseif x < 0 then
        return -1
    else
        return 0
    end
end

function findTarget(default_target, is_currently_mad)
    local target = default_target

    if is_currently_mad then
        target = player
        --GamePrint("target is player 1")
    elseif #food > 0 then
        target = food[1]
        if times_angered == 0 and current_animation == "dormant" then
            setAnimationData(entity_id,1,"peek")
        end
        --GamePrint("target is food 2")
    elseif times_angered > 0 or distance_from_player < notice_player_radius then
        target = player
        if current_animation == "dormant" then
            setAnimationData(entity_id,1,"peek")
        end
        --GamePrint("target is player 3")
    else
        if times_angered == 0 and current_animation == "peek" then
            setAnimationData(entity_id,1,times_angered > 0 and "stand" or "dormant")
        end
        --GamePrint("target is default target 4")
    end

    return target
end

function checkForAngerEnd(anger_expiration_frame)
    if GameGetFrameNum() == anger_expiration_frame then
        ComponentSetValue2(vsc_anger_data,"value_bool",false)
        if is_currently_emerging then
            EntityKill(entity_id)
            EntityLoad("data/entities/animals/boss_adult_centipede/boss_adult_centipede.xml", pos_x, pos_y)
        end
    end
end

function setAnimationData(entity_id,animation_frames,animation_to_play)
	local sprite_comp = EntityGetFirstComponentIncludingDisabled(entity_id,"SpriteComponent")
    ComponentSetValue2(sprite_comp,"rect_animation",animation_to_play)
	ComponentSetValue2(vsc_animation_data,"value_int",GameGetFrameNum() + animation_frames)
	ComponentSetValue2(vsc_animation_data,"value_string",animation_to_play)
end

function checkForAnimationTimeout(entity_id,animation_expiration_frame)
    if GameGetFrameNum() == animation_expiration_frame then
        local sprite_comp = EntityGetFirstComponentIncludingDisabled(entity_id,"SpriteComponent")
        ComponentSetValue2(sprite_comp,"rect_animation",idle_animation_name)
        ComponentSetValue2(vsc_animation_data,"value_string",idle_animation_name)
    end
end

function runShakeAnimation(entity_id,shake_start_frame,shake_duration)
    local current_shake_progress = GameGetFrameNum() - shake_start_frame
    local rot_offset = 0

    if shake_duration == 0 then
        rot_offset = lerp(ComponentGetValue2(vsc_animation_shake_data,"value_float"), 0, 0.95)
        ComponentSetValue2(vsc_animation_shake_data,"value_float",rot_offset)
        return
    elseif shake_start_frame + shake_duration == GameGetFrameNum() then
        ComponentSetValue2(vsc_animation_shake_data,"value_int",0)
        ComponentSetValue2(vsc_animation_shake_data,"value_string","0")
        return
    else
        --0 progress = 0 rot
        --20 progress = -30 rot
        --40 progress = 0 rot
        --60 progress = 30 rot
        --80 progress = 0 rot
        --100 progress = -30 rot
        --120 progress = 0 rot

        rot_offset = -math.sin((current_shake_progress / shake_animation_full_cycle_length) * 2 * math.pi) * (shake_animation_max_rot_deviation * (1 -(current_shake_progress / shake_duration)))
    end

    ComponentSetValue2(vsc_animation_shake_data,"value_float",rot_offset)
end















------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------- Core Operation Functions --------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function rotationUpdateCycle(current_target, rotate_speed)
    local ctarg_x,ctarg_y = EntityGetTransform(current_target)
    local rotation_goal = math.atan2( ( ctarg_y - pos_y ), ( ctarg_x - pos_x ) )
    local new_rotation = rotateTo(rotation, rotation_goal, default_target, rotate_speed, rotation_offset, is_currently_mad)

    ComponentSetValue2(vsc_rotation_data,"value_float",new_rotation)
    local new_rot = new_rotation + math.rad(rotation_offset)


    EntitySetTransform(entity_id,pos_x,pos_y,new_rot)
end

function animationUpdateCycle(current_irritation,current_target)
    if current_irritation >= 1.0 and is_currently_mad == false and times_angered >= 2 and is_currently_emerging == false then
        --Emerge
        ComponentSetValue2(vsc_animation_data,"value_bool",true)
        ComponentSetValue2(vsc_anger_data,"value_bool",true)
        ComponentSetValue2(vsc_anger_data_timer,"value_int",GameGetFrameNum() + roar_long_animation_duration)
        setAnimationData(entity_id,roar_long_animation_duration,roar_animation_name)

        GamePlaySound( "mods/Apotheosis/mocreeps_audio.bank", "mocreeps_audio/animals/boss_flesh_monster/transition", pos_x, pos_y )
    elseif current_irritation >= 1.0 and is_currently_mad == false then
        --Roar and update anger values
        ComponentSetValue2(vsc_anger_data,"value_bool",true)
        ComponentSetValue2(vsc_anger_data_timer,"value_int",GameGetFrameNum() + angry_at_player_duration)
        ComponentSetValue2(vsc_anger_data,"value_string",tostring(times_angered + 1))
        ComponentSetValue2(vsc_anger_data,"value_float",0.0)
        ComponentSetValue2(vsc_unstuck_data,"value_int",GameGetFrameNum() + 1200)
        setAnimationData(entity_id,roar_animation_duration,roar_animation_name)

        --Play Roar Sound
        --Roar animation duration should match the duration of the centipedes roar
        GamePlaySound( "mods/Apotheosis/mocreeps_audio.bank", "mocreeps_audio/animals/boss_flesh_monster/transition", pos_x, pos_y )
    elseif distance_from_food < 32 then
        setAnimationData(entity_id,108,eat_animation_name)
        GamePlaySound( "data/audio/Desktop/materials.bank", "collision/meat", pos_x, pos_y )
        GamePlaySound( "data/audio/Desktop/animals.bank", "animals/worm/attack_bite", pos_x, pos_y )
        EntityAddComponent2(
			food[1],
			"LifetimeComponent",
			{
				lifetime=1
			}
		)
        ComponentSetValue2(vsc_unstuck_data,"value_int",GameGetFrameNum())
        --EntityKill(food[1])
    elseif EntityHasTag(current_target,"centipede_food") == false and times_angered > 0 and current_animation == idle_animation_name and math.random(1,shake_animation_chance) == 1 then
        --shake head
        --Rotational animation
        setAnimationData(entity_id,shake_head_animation_duration,shake_animation_name)
        ComponentSetValue2(vsc_animation_shake_data,"value_int",GameGetFrameNum())
        ComponentSetValue2(vsc_animation_shake_data,"value_string",tostring(shake_head_animation_duration))
    else
        --passive
    end
end

function stuckCheckUpdateCycle(current_animation)
    
    if last_frame_fed + no_feed_anger_timer < GameGetFrameNum() then
        local ants = EntityGetInRadiusWithTag(pos_x, pos_y, 256, "hittable")
        local ant = 0
        for k=1,#ants do
            if EntityGetName(ants[k]) == "centipede_food_barer" then ant = ants[k] break end
        end

        ComponentSetValue2(vsc_anger_data,"value_float",1.0)
        ComponentSetValue2(vsc_unstuck_data,"value_int",GameGetFrameNum())

        if ant ~= 0 then
            if is_currently_emerging then
                local vsc_navigation_data = EntityGetComponentIncludingDisabled(entity_id,"VariableStorageComponent")[3]
                ComponentSetValue2(vsc_navigation_data,"value_bool",true)
            else
                EntitySetComponentIsEnabled( ant, EntityGetFirstComponentIncludingDisabled(ant,"CharacterCollisionComponent"), false )
                local vsc_burrowing_data = EntityGetComponentIncludingDisabled(ant,"VariableStorageComponent")[2]
                ComponentSetValue2(vsc_burrowing_data,"value_bool",true)
                ComponentSetValue2(vsc_burrowing_data,"value_float",0.5)
                ComponentSetValue2(vsc_burrowing_data,"value_int",pos_y + 50)
                ComponentSetValue2(vsc_burrowing_data,"value_string","kill")
            end
        end
    end
end












------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------- Operations -----------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



local current_target = findTarget(default_target, is_currently_mad)



rotationUpdateCycle(current_target, rotation_speed)
animationUpdateCycle(current_irritation,current_target)
checkForAngerEnd(anger_expiration_frame)
checkForAnimationTimeout(entity_id,current_animation_expiration_frame)
runShakeAnimation(entity_id,shake_start_frame,shake_duration)
stuckCheckUpdateCycle(current_animation)