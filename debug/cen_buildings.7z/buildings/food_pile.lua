
local entity_id = GetUpdatedEntityID()
local pos_x, pos_y = EntityGetTransform(entity_id)
local targets = EntityGetInRadiusWithTag(pos_x, pos_y, 512, "hittable") or {}
local centipede_head = EntityGetInRadiusWithTag(pos_x, pos_y, 512, "centipede_head") or {}
local found = false

local ant_opts = {"ant_fire","ant_suffocate","ant"}
math.randomseed(GameGetFrameNum())
local ant_to_spawn = table.concat({"data/entities/animals/boss_adult_centipede/buildings/food_barer/",ant_opts[math.random(1,#ant_opts)],".xml"})

for k=1,#targets do
    if EntityGetName(targets[k]) == "centipede_food_barer" then
        found = true
        break
    end
end

if found == false and #centipede_head > 0 then
    local ant_id = EntityLoad(ant_to_spawn, pos_x, pos_y + 50)
    local vsc_burrowing_data = EntityGetComponentIncludingDisabled(ant_id,"VariableStorageComponent")[2]
    local vsc_navigation_data = EntityGetComponentIncludingDisabled(ant_id,"VariableStorageComponent")[3]

    ComponentSetValue2(vsc_burrowing_data,"value_int",pos_y)
    ComponentSetValue2(vsc_burrowing_data,"value_string",tostring(GameGetFrameNum() + 240))
    ComponentSetValue2(vsc_navigation_data,"value_int",EntityGetWithTag("centipede_head")[1])
end